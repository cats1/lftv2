define(['jquery', 'i18n!../../nls/mess'], function($, i18n) {
    return {
        loadBasic: function(){

        },
        init: function(){
          console.log(66)
        }
    }
})