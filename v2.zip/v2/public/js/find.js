
define(['app/api', 'bootstrap'], function (api, bootstrap) {
	//console.log(common.test())
	/*api.getUser().then(function(user){
		console.log(user)
	})*/
	//api.getUserByJsonp()
	api.loadUser()
	/*console.log(i18n)
	$("#test").after('<button class="btn btn-default">'+i18n.edit+'</button>')*/
})