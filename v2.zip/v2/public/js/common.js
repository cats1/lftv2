
define('common', ['jquery','bootstrap'], function ($, bootstrap) {
	console.log(bootstrap)
  return {
  	test: function () {
  		return 'hahah'
  	}
  }
})