define({
	'edit': '编辑',
	'foot': {
		'lpage': '版權所有 2015-<i class="curyear"></i> 南京訪客樂網絡科技有限公司. 保留壹切權利.',
		'rpage': '<a target="_blank" href="http://www.miitbeian.gov.cn">蘇ICP備15058768号</a>'
	},
    'nav': {
        'version': 'V2.2.0',
        'navlist': [{
            'dir': 'index',
            'name': '首頁',
            'children': []
        }, {
            'dir': 'index',
            'name': '人員',
            'children': [{
                'dir': 'index',
                'name': '公司員工',
                'children': []
            }, {
                'dir': 'index',
                'name': '常駐訪客',
                'children': []
            }, {
                'dir': 'index',
                'name': '訪客黑名單',
                'children': []
            }]
        }, {
            'dir': 'index',
            'name': '通知',
            'children': []
        }, {
            'dir': 'index',
            'name': '自定義設置',
            'children': [{
                'dir': 'index',
                'name': '前臺設置',
                'children': []
            }, {
                'dir': 'index',
                'name': '預約邀請',
                'children': []
            }, {
                'dir': 'index',
                'name': '手機門禁',
                'children': []
            }, {
                'dir': 'index',
                'name': '會議室管理',
                'children': []
            }]
        }, {
            'dir': 'index',
            'name': '會議',
            'children': []
        }],
        'homepage': {
            'dir': 'account',
            'name': '官網首頁',
            'icon': 'fa-user',
            'children': []
        },
        'userinfo': [{
            'dir': 'account',
            'name': '賬戶信息',
            'icon': 'fa-user',
            'children': []
        }, {
            'dir': 'index',
            'name': '退出登錄',
            'icon': 'fa-power-off',
            'children': []
        }]
    },
    'account': {
        'leftMenu': {
            'title': '账户信息',
            'menulist': [{
                'dir': 'basic',
                'name': '基本资料',
                'icon': 'fa-power-off',
                'children': []
            },{
                'dir': 'safe',
                'name': '账户安全',
                'icon': 'fa-power-off',
                'children': []
            },{
                'dir': 'stage',
                'name': '前台验证账号',
                'icon': 'fa-power-off',
                'children': []
            },{
                'dir': 'charge',
                'name': '充值管理',
                'icon': 'fa-power-off',
                'children': []
            },{
                'dir': 'company',
                'name': '多企业服务模式',
                'icon': 'fa-power-off',
                'children': []
            }]
        }
    }
})