define(['jquery', 'i18n!../../nls/mess', 'css!../../../../module/account/stage', 'btable'], function($, i18n, bcss, btable) {
    function stateFormatter(value, row, index) {
        if (index === 2) {
            return {
                disabled: true
            };
        }
        if (index === 5) {
            return {
                disabled: true,
                checked: true
            }
        }
        return value;
    }

    function operateFormatter(value, row, index) {
        return [
            '<a class="like" href="javascript:void(0)" title="Like">',
            '修改</a>  ',
            '<a class="remove" href="javascript:void(0)" title="Remove">',
            '删除</a>'
        ].join('');
    }
    window.operateEvents = {
        'click .like': function(e, value, row, index) {
            alert('You click like action, row: ' + JSON.stringify(row));
        },
        'click .remove': function(e, value, row, index) {
            $table.bootstrapTable('remove', {
                field: 'id',
                values: [row.id]
            });
        }
    };
    return {
        loadStage: function(els) {
            require(['text!/lft/v2/module/account/stage.html!strip'], function(template) {
                $(els).append(template);
                $('#table').bootstrapTable({
                    columns: [{
                        field: 'state',
                        formatter: stateFormatter,
                        checkbox: true,
                        title: '操作'
                    }, {
                        field: 'id',
                        title: '验证端账号'
                    }, {
                        field: 'name',
                        title: '密码'
                    }, {
                        field: 'price',
                        title: '姓名'
                    }, {
                        field: 'operate',
                        title: '操作',
                        align: 'center',
                        events: operateEvents,
                        formatter: operateFormatter
                    }],
                    data: [{
                        id: 1,
                        name: 'Item 1',
                        price: '$1'
                    }, {
                        id: 2,
                        name: 'Item 2',
                        price: '$2'
                    }, {
                        id: 3,
                        name: 'Item 1',
                        price: '$1'
                    }, {
                        id: 4,
                        name: 'Item 2',
                        price: '$2'
                    }],
                    striped: true
                });
                $(window).resize(function() {
                    $('#table').bootstrapTable('resetView');
                });
            })
        },
        init: function(els) {
            this.loadStage(els);
        }
    }
})