define(['jquery', 'i18n!../../nls/mess', 'css!../../../../module/account/basic'], function($, i18n) {
    return {
        loadBasic: function(els) {
            require(['text!/lft/v2/module/account/basic.html!strip'], function(template) {
                $(els).append(template);
                var lv = 'zh-cn';
                if (window.localStorage.lftlang) {
                    lv = window.localStorage.lftlang
                }
                $("#" + lv).prop('checked', true);
                $("input[name='languageversion']").on('change', function(event) {
                    event.preventDefault();
                    var ls = $(this).attr('id');
                    window.localStorage.lftlang = ls;
                    location.reload();
                });
            })
        },
        init: function(els) {
            this.loadBasic(els);

        }
    }
})