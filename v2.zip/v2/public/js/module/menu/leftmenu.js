define(['jquery', 'i18n!../../nls/mess','../account/basic','../account/safe','../account/stage','../account/stage'], function($, i18n, basic, safe, stage) {
    return {
        loadLeftMenu: function(els) {
            require(['text!/lft/v2/module/menu/leftmenu.html!strip'], function(template) {
                var leftMenu = i18n.account.leftMenu;
                var leftlist = leftMenu.menulist;
                $(els).append(template);
                $(".menulist dt").text(leftMenu.title);
                leftlist.forEach(function(ele, index) {
                    var moduleDir = ele.dir;
                    var ddHtml = $('<dd id="'+ele.dir+'">\
                                            <span class="bluelines"></span>\
                                            <a href="javascript:void(0)">' + ele.name + '</a>\
                                        </dd>');
                    $(ddHtml).off('click');
                    $(ddHtml).on('click', function(e) {
                        $(".menulist dd").removeClass('active');
                        $(this).addClass('active');
                        $("#asection").empty();
                        if (moduleDir == 'basic') {
                            basic.init('#asection');
                        } else if (moduleDir == 'safe') {
                            safe.init('#asection');
                        } else if (moduleDir == 'stage') {
                            stage.init('#asection');
                        }
                    });
                    $(".menulist").append(ddHtml);
                });
                $(".menulist dd").eq(0).addClass('active');
                basic.init('#asection');

            })
        }
    }
})