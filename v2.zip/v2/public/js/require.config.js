var language = document.cookie.match(/language=(^;]+)/),
locale = 'zh-cn';
if (window.localStorage.lftlang) {
 locale = window.localStorage.lftlang
}
requirejs.config({
	baseUrl: './public/js', //加载文件根路径
	//urlArgs: '_=' + new Date().getTime(), //下载文件是在url后面增加额外的query参数
	paths: { // 库框架指定路径
		'jquery': './lib/jquery-1.11.3.min',
		'bootstrap': './lib/bootstrap/bootstrap.min',
		'utils': './utils/utils',
		'text': './lib/require/text',
		'i18n': './lib/require/i18n',
		'css': './lib/require/css',
		'bootnav': './module/header/bootnav',
		'btable': './lib/boottable/bootstrap-table.min'
	},
	shim: { //不支持AMD的模块
      'bootstrap': [
        'jquery',
        'css!/../lib/bootstrap/bootstrap.min'
      ],
      'bootnav': [
        'jquery',
        'bootstrap',
        'css!/../lib/bootnav/bootsnav'
      ],
      'btable': [
        'jquery',
        'bootstrap',
        'css!/../lib/boottable/bootstrap-table.min'
      ]
	},
	map: {
		/*'*': {
          css: './css/css.min'
		}*/
	},
	/*map: { //指定不同加载依赖
      'app/api': {
      	'jquery': 'lib/jquery-1.11.3.min'
	  },
	  'app/api2': {
      	'jquery': 'lib/jquery-3.2.1.min'
      }
	},*/
	waitSeconds: 0, //下载js等待时间，默认7s,设为0则禁用等待时间
	config: {
		text: {
          onXhr: function (xhr, url) {
            xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest')
          }
		},
		i18n: {
			locale: typeof locale !== 'undefined' ? locale : 'zh-cn'
		}
	}
})