define(['app/api'], function (api) {
	api.loadMHeader()
	api.loadFooter()
});