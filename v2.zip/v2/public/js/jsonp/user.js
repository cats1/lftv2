define({
	'name': 'lana-jsonp'
})