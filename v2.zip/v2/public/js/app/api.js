
define(['jquery','utils','i18n!../nls/mess','../module/header/header'], function($, utils, i18n, header){
  return {
  	getUser: function () {
  		var def = $.Deferred();
  		require(['./app/user'], function(user){
  			def.resolve(user)
  		})
  		return def
  	},
  	getUserByJsonp: function () {
  		/*$.ajax({
  			url: 'http://localhost/ipjia/iphome_homepage1/public/js/jsonp/user.js',
  			dataType: 'jsonp',
  			jsonpCallback: 'onloaded',
  			success: function (data) {
  				console.log(data)
  			}
  		})*/
  		require(['http://localhost/ipjia/iphome_homepage1/public/js/jsonp/user.js'], function(user){
  			console.log(user)
  		})
  	},
  	loadUser: function () {
  		require(['text!/ipjia/iphome_homepage1/user.html!strip'], function(template){
          $("#test").html(template)
  		})
  	},
    loadMHeader: function(){
      header.loadMHeader()
    },
    loadFooter: function(){
      require(['text!/lft/v2/module/footer/foot.html!strip'], function(template){
          $("#footer").html(template);
          $('.foot-text').html(i18n.foot.lpage);
          var curYear = new Date().getFullYear();
          $(".curyear").text(curYear);
          $('.foot-text').append(i18n.foot.rpage)

      })
    },
    loadAccountMenu: function(){
      
    }
  }
})
/*function onloaded (user) {
	console.log(user)
}*/