define({
	'name': 'lana'
})