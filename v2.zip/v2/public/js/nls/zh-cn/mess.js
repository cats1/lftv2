define({
    'edit': '编辑',
    'foot': {
        'lpage': '版权所有 2015-<i class="curyear"></i> 南京访客乐网络科技有限公司. 保留一切权利.',
        'rpage': '<a target="_blank" href="http://www.miitbeian.gov.cn">苏ICP备15058768号</a>'
    },
    'nav': {
        'version': 'V2.2.0',
        'navlist': [{
            'dir': 'index',
            'name': '首页',
            'children': []
        }, {
            'dir': 'index',
            'name': '人员',
            'children': [{
                'dir': 'index',
                'name': '公司员工',
                'children': []
            }, {
                'dir': 'index',
                'name': '常驻访客',
                'children': []
            }, {
                'dir': 'index',
                'name': '访客黑名单',
                'children': []
            }]
        }, {
            'dir': 'index',
            'name': '通知',
            'children': []
        }, {
            'dir': 'index',
            'name': '自定义设置',
            'children': [{
                'dir': 'index',
                'name': '前台设置',
                'children': []
            }, {
                'dir': 'index',
                'name': '预约邀请',
                'children': []
            }, {
                'dir': 'index',
                'name': '手机门禁',
                'children': []
            }, {
                'dir': 'index',
                'name': '会议室管理',
                'children': []
            }]
        }, {
            'dir': 'index',
            'name': '会议',
            'children': []
        }],
        'homepage': {
            'dir': 'account',
            'name': '官网首页',
            'icon': 'fa-user',
            'children': []
        },
        'userinfo': [{
            'dir': 'account',
            'name': '账户信息',
            'icon': 'fa-user',
            'children': []
        }, {
            'dir': 'index',
            'name': '退出登录',
            'icon': 'fa-power-off',
            'children': []
        }]
    },
    'account': {
        'leftMenu': {
            'title': '账户信息',
            'menulist': [{
                'dir': 'basic',
                'name': '基本资料',
                'icon': 'fa-power-off',
                'children': []
            },{
                'dir': 'safe',
                'name': '账户安全',
                'icon': 'fa-power-off',
                'children': []
            },{
                'dir': 'stage',
                'name': '前台验证账号',
                'icon': 'fa-power-off',
                'children': []
            },{
                'dir': 'charge',
                'name': '充值管理',
                'icon': 'fa-power-off',
                'children': []
            },{
                'dir': 'company',
                'name': '多企业服务模式',
                'icon': 'fa-power-off',
                'children': []
            }]
        }
    }
})