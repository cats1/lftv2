define(['app/api','module/menu/leftmenu'], function (api, leftmenu) {
	api.loadMHeader()
	api.loadFooter();
	leftmenu.loadLeftMenu('.page-main .col-md-3');
});