define(['jquery', 'i18n!../../nls/mess', 'css!../../../../module/account/safe'], function($, i18n) {
    return {
        loadSafe: function(els) {
            require(['text!/lft/v2/module/account/safe.html!strip'], function(template) {
                $(els).append(template);
            })
        },
        init: function(els) {
            this.loadSafe(els);

        }
    }
})