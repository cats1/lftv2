define(['bootstrap'], function ($) {
	console.log(66);
})