define(['jquery', 'i18n!../../nls/mess', 'bootnav'], function($, i18n, bootnav) {
    return {
        getUser: function() {
            var def = $.Deferred();
            require(['./app/user'], function(user) {
                def.resolve(user)
            })
            return def
        },
        getUserByJsonp: function() {
            require(['http://localhost/ipjia/iphome_homepage1/public/js/jsonp/user.js'], function(user) {
                console.log(user)
            })
        },
        loadMHeader: function() {
            require(['text!/lft/v2/module/header/mhead.html!strip'], function(template) {
                var navObjText = i18n.nav;
                var navlist = navObjText.navlist;
                var homepage = navObjText.homepage;
                var userInfo = navObjText.userinfo;
                $("#mheader").html(template);
                $('.versionmiddle').text(navObjText.version);
                navlist.forEach(function(element, index) {
                    var cArray = element.children;
                    if (cArray.length > 0) {
                        var fHtml = $('<li class="dropdown">\
                	  	<a href="' + element.dir + '.html" class="dropdown-toggle" data-toggle="dropdown">' + element.name + '</a>\
                	  	<ul class="dropdown-menu"></ul></li>');
                        cArray.forEach(function(cel, cindex) {
                            $(fHtml).find('ul').append('<li><a href="' + cel.dir + '.html">' + cel.name + '</a></li>');
                        });
                        $('.navbar-left').append(fHtml);
                    } else {
                        $('.navbar-left').append('<li><a href="' + element.dir + '.html">' + element.name + '</a></li>');
                    }
                });
                bootnav.initialize();
                userInfo.forEach(function(element, index) {
                	$('.navbar-right .dropdown-menu').append('<li><a href="' + element.dir + '.html"><i class="fa '+element.icon+'"></i>' + element.name + '</a></li>');
                });
                $('.navbar-right .dropdown-menu li:last-child').prepend('<li class="divider"></li>');
                $('.navbar-right').prepend('<li ><a href="'+homepage.dir+'" target="view_window">'+homepage.name+'</a></li>');
            })
        }
    }
})