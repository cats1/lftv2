define({
	'zh-cn': true,//中文简体
	'en': true,//英文
	'zh-hk': true//中文繁体
})