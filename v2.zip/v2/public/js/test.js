requirejs.config({
	baseUrl: './public/js', //加载文件根路径
	//urlArgs: '_=' + new Date().getTime(), //下载文件是在url后面增加额外的query参数
	paths: { // 库框架指定路径
		'jquery': './lib/jquery-1.11.3.min'
	}
})
define(['./lib/jquery-1.11.3.min'], function($){
	console.log($)
})