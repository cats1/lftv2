define(['app/api', 'bootstrap'], function (api, bootstrap) {
	api.loadHeader()
	api.loadFooter()
});